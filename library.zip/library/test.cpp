﻿#include<iostream>
#include<string>
#include "Triangle.h"
using namespace std;
int main() {
	double a, b, c;
	cout << "请输入三角形三边:";
	cin >> a >> b >> c;
	Triangle t1;
	t1.set(a, b, c);//函数都是t1的成员函数，使用时要用t1.
	//t1.getPerimeter();
	//t1.getArea();
	//t1.getType();
    t1.show();
	return 0;
}