﻿#include "Triangle.h"
#include<cmath>
bool Triangle::check(double x, double y, double z) {
	if (x <= 0 || y <= 0 || z <= 0) {
		return false;
	}
	else {
		return (x + y > z) && (x + z > y) && (y + z > x);//三个条件都符合返回1
	}
}
Triangle::Triangle() {
	A = 3;
	B = 3;
	C = 3;
}
Triangle::Triangle(double sa, double sb, double sc) {
	if (check(sa, sb, sc))
	{
		A=sa;
		B=sb;
		C=sc;
	}  
	else {
		cout<<"警告，输入三边不能构成一个三边形,重置为3,3,3"<<endl;
		A = 3;
		B = 3;
		C = 3;

	}
}
//修改三边
void Triangle::set(double sa, double sb, double sc) {
	if (check(sa, sb, sc))
	{
		A = sa;
		B = sb;
		C = sc;
	}
	else {
		cout << "设置失败，三边不合法" << endl;
	}
}
//获取三边
double Triangle::getA() {
	return A;
}//常成员函数，只获取数据
double Triangle::getB(){
	return B;
}
double Triangle::getC(){
	return C;
}
//计算周长
double Triangle::getPerimeter() {
	Perimeter = A +B + C;
	return A + B + C;
}
//计算面积
double Triangle::getArea() {
	double p = (A + B + C) / 2.0;
	Area = sqrt(p * (p - A) * (p - B) * (p - C));
	return sqrt(p * (p - A) * (p - B) * (p - C));
}
//判断三角形的类型
string Triangle::getType() {
	if ((A == B) && (B == C) && (A == C)) {
		return "等边三角形";
	}
	else if ((A == B) || (A==C) || (B ==C)) {
		if ((C * C == A * A + B * B) || (A * A == C * C + B * B) || (B * B == A * A +C * C)) {
			return "等腰直角三角形" ;
		}
		else return "等腰三角形" ;
	}
	else if ((C * C == A * A + B * B) || (A * A == C * C + B * B) || (B * B == A * A + C * C)) {
		return "直角三角形" ;
	}
	else {
		return "普通三角形" ;
	}
}
//输出
void Triangle::show(){
	cout << "三角形的三边：" << A <<" " << B<<" " << C << endl;
	cout << "三角形的周长是：" << getPerimeter() << endl;
	cout << "三角形的面积是：" << getArea() << endl;
	cout << "三角形的类型是：" << getType() << endl;
	
}