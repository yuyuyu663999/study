﻿#pragma once
#include<iostream>
#include<string>
using namespace std;
class Triangle
{
private://private：只能在这个类自己的函数内部访问，main/其他类不能直接读写（防止外界乱赋值）
	double A;
	double B;
	double C;
	double Perimeter;
	double Area;
	bool check(double x, double y, double z);
public://public:main函数、外部代码可以直接调用
	Triangle();//默认构造，自动初始化三边
	Triangle(double sa, double sb, double sc);//创建对象同时直接传入三边，内部校验合法性
	void set(double sa, double sb, double sc);//修改三边
	//获取三边，读取私有变量，外部只能通过get函数获取边长数据
	double getA() ;
	double getB() ;
	double getC() ;
	double getPerimeter();//周长
	double getArea();//面积
	string getType();//判断三角形的类型
	void show();//输出
};

